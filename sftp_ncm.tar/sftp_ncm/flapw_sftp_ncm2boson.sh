#!/bin/bash

# Define variable
REMOTE_USER="asyamsul24"
REMOTE_HOST="boson.nd.phen.mie-u.ac.jp"
REMOTE_DIR="$HOME/sync_folder"
LOCAL_DIR="$HOME/sync_folder"

# Check if local directory exist
if [ ! -d "$LOCAL_DIR" ]; then
  echo "Error: Local directory '$LOCAL_DIR' does not exist."
  exit 1
fi

# Start the SFTP
sftp $REMOTE_USER@$REMOTE_HOST <<EOF
cd $REMOTE_DIR
lcd $LOCAL_DIR
mput *
bye
EOF

# Check if SFTP complete
if [ $? -eq 0 ]; then
  echo "All files in '$LOCAL_DIR' successfully transferred to '$REMOTE_HOST:$REMOTE_DIR'."
else
  echo "SFTP transfer failed."
  exit 1
fi

